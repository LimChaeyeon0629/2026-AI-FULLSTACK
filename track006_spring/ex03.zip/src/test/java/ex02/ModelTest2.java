package ex02;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.the703.dao.UserMapper;
import com.the703.dto.AuthDto;
import com.the703.dto.AuthListDto;
import com.the703.dto.UserDto;
import com.the703.service.UserService;

@RunWith(SpringJUnit4ClassRunner.class)	//1.spring ����
// @ContextConfiguration(locations = "classpath:config/*-context.xml") //2.��������
@ContextConfiguration(locations = 
			{"classpath:config/root-context.xml", "classpath:config/security-context.xml"}) //2.��������
public class ModelTest2 {
	@Autowired UserMapper user;
	@Autowired UserService service;
	@Autowired @Qualifier("passwordEncoder") PasswordEncoder pwencoder;
	// import org.springframework.security.crypto.password.PasswordEncoder;
	
	/* security */
	@Test
	public void test4() {
		AuthDto dto2 = new AuthDto();	dto2.setEmail("a@a");
		System.out.println( user.readAuth(dto2) );
	}
	
	@Ignore //@Test
	public void test3() {
		/* �α��ν� �ΰ� (�ش����� ���� ��������) */
		AuthDto dto2 = new AuthDto();
		dto2.setEmail("a@a");
		System.out.println( user.readAuth(dto2) );
		
		
		/* ���ѵ�� ȸ��(MEMBER & ADMIN) */
//		AuthDto dto1 = new AuthDto();
//		dto1.setEmail("a@a"); dto1.setAuth("ROLE_MEMBER");
//		dto1.setEmail("a@a"); dto1.setAuth("ROLE_ADMIN");
//		System.out.println( user.insertAuth(dto1) );
		
//		AuthListDto result = readAuth(AuthDto dto);
		
		
		/* ȸ������ (��ȣȭ) */
//		UserDto dto = new UserDto();
//		dto.setNickname("a");
//		dto.setBpass( pwencoder.encode("a") );
//		dto.setEmail("a@a");
//		dto.setMobile("010-000-0000");
//		System.out.println( service.insert(dto) );
		
//		System.out.println( "��ȣȭ Ȯ��: " + service.findByUno(11) );
	}
	
	@Ignore //@Test
	public void test2() throws UnknownHostException {
		//�̸����ߺ�: findByEmail
//		System.out.println( "�̸����ߺ� Ȯ��: " + service.findByEmail("aaa@gmail.com") );
		
		//����������: findByUno
		System.out.println( "���� ����������: " + service.findByUno(8) );
		
		//�α���: findLogin
		UserDto dto2 = new UserDto();
		dto2.setEmail("aaa@gmail.com");
		dto2.setBpass("aaa");
		System.out.println( "���� �α���: " + service.findLogin(dto2) );
		
		//ȸ������ join
//		UserDto dto = new UserDto();
//		dto.setNickname("aaaa");
//		dto.setBpass("aaa");
//		dto.setEmail("aaa@gmail.com");
//		dto.setMobile("000-111-1111");
//		dto.setBip(InetAddress.getLocalHost().getHostAddress());
//		user.insert(dto);
//		System.out.println( service.insert(dto) );
	}
	
	
	
	@Ignore //@Test
	public void test1() throws UnknownHostException {
		//�̸����ߺ�: findByEmail
//		System.out.println( "�̸����ߺ� Ȯ��: " + user.findByEmail("aaa@gmail.com") );
		
		//����������: findByUno
		System.out.println( "����������: " + user.findByUno(7) );
		
		//�α���: findLogin
		UserDto dto2 = new UserDto();
		dto2.setEmail("aaa@gmail.com");
		dto2.setBpass("aaa");
		System.out.println( "�α���: " + user.findLogin(dto2) );
		
		
		//ȸ������: insert
//		UserDto dto = new UserDto();
//		dto.setNickname("aaa");
//		dto.setBpass("aaa");
//		dto.setEmail("aaa@gmail.com");
//		dto.setMobile("000-111-1111");
//		dto.setBip(InetAddress.getLocalHost().getHostAddress());
//		user.insert(dto);
//		System.out.println( user.insert(dto) );
	}
}
