package com.the703.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.the703.dto.UserDto;
import com.the703.service.UserService;

@Controller
@RequestMapping("/security/*")
public class SecurityController { // URL ��û �޾Ƽ� � JSP �������� ����

	@Autowired UserService service;
	
	@RequestMapping("/all")
	public String all() { return "security/all"; }
	@RequestMapping("/member")
	public String member() { return "security/member"; }
	
	@RequestMapping("/join")
	public String join() { return "security/join"; }
	@RequestMapping(value="/join", method=RequestMethod.POST)
	public String join_post(UserDto dto, RedirectAttributes rttr) { 
		String result="ȸ�����Խ���";
		if( service.insert(dto) > 0 ) { result = "ȸ�����Լ���"; }
		rttr.addFlashAttribute("success", result);
		return "redirect:/security/join"; 
	}
	@RequestMapping("/login")
	public String login() { return "security/login"; }
	
	@RequestMapping("/fail")
	public String fail() { return "security/fail"; }
	@RequestMapping("/mypage")
	
	
	
	// Authentication - Principal ���� �α����� ����� ����
	public String mypage( Principal principal, Model model ) { 
		System.out.println("................." + principal);
		System.out.println("................." + principal.getName()); //username - email
//		model.addAttribute("email", principal.getName()); //email mypage���

		// mapper - email �˻� �� �ش� ���� ���� �������� 	- mapper&service 
		//											- �˻��� ����������ȸ(UserDto) / �Ķ����Ÿ���� email��(String email)
		model.addAttribute("dto", service.findByEmailUserInfo( principal.getName() ));
		
		return "security/mypage"; }

}
