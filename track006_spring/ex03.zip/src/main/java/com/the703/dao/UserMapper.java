package com.the703.dao;

import com.the703.dto.AuthDto;
import com.the703.dto.AuthListDto;
import com.the703.dto.UserDto;

@Mapper
public interface UserMapper { // DB�� ���� ����Ǵ� ���� (SQL ����) mybatis
	public int insert(UserDto dto);
	public int findLogin(UserDto dto);
	public UserDto findByUno(int uno);
	public String findByEmail(String email); //�̸����ߺ�Ȯ��
	public String findByNickname(String nickname); //�г����ߺ�Ȯ��
	public int update(UserDto dto);
	public int delete(int uno);
	
	/* security - authorities */
	/* security - authorities */
	public int insertAuth(AuthDto dto);
	public AuthListDto readAuth(AuthDto dto);
	public UserDto findByEmailUserInfo(String email);
}
