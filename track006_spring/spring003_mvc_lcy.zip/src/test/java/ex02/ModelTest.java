package ex02;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.the703.dao.TestMapper;
import com.the703.dao.BoardMapper;
import com.the703.dto.BoardDto;
import com.the703.service.BoardService;

@RunWith(SpringJUnit4ClassRunner.class)	//1.spring ����
@ContextConfiguration(locations = "classpath:config/root-context.xml") //2.��������
public class ModelTest {
	@Autowired ApplicationContext context; //bean (spring�� �����ϴ� ��ü��)
	@Autowired DataSource dataSource;
	@Autowired SqlSession sqlSession;
	@Autowired TestMapper testMapper;
	
	@Autowired BoardMapper board;
	@Autowired BoardService service;
	
	@Test
	public void test7() {
		HashMap<String, Integer> map = new HashMap();
		map.put("start", 0);
		map.put("end", 10);
		System.out.println( board.select10(map) );
		
		System.out.println( board.selectCnt() );
	}
	
	@Ignore //@Test
	public void test1() {
		System.out.println(context);
	}

	@Ignore //@Test
	public void test2() {
		System.out.println(dataSource);
	}
	
	@Ignore //@Test
	public void test3() {
		System.out.println(sqlSession);
	}
	
	@Ignore //@Test
	public void test4() {
		System.out.println(testMapper.now());
	} // �޼���� now()
	
	@Ignore //@Test
	public void test5() {
		//����
//		System.out.println( board.delete(8) );
		
		//����
//		BoardDto dto2 = new BoardDto();
//		dto2.setBname("ddd");
//		dto2.setBpass("ddd");
//		dto2.setBtitle("ddd");
//		dto2.setBcontent("DDD");
//		dto2.setBip("12.12.12");
//		dto2.setBno(8);
//		board.update(dto2);
//		System.out.println( board.update(dto2) ); //������ �ټ�1

		//insert
//		BoardDto dto = new BoardDto();
//		dto.setBname("cy_name");
//		dto.setBpass("cy_pass");
//		dto.setBtitle("cy_title");
//		dto.setBcontent("cy_content");
//		dto.setBip(InetAddress.getLocalHost().getHostAddress());
//		board.insert(dto);
//		System.out.println( board.insert(dto) ); //������ �ټ�1
		
		//�������
//		System.out.println( board.select(1) );
		
		//��ü���
//		System.out.println(board.selectAll());
	}
	
	@Ignore //@Test
	public void test6() throws UnknownHostException {
		//����
//		BoardDto dto = new BoardDto();
//		dto.setBno(10);
//		System.out.println( service.delete(dto) );
		
		//����
//		BoardDto dto = new BoardDto();
//		dto.setBname("first");
//		dto.setBpass("1111");
//		dto.setBno(11);
//		dto.setBtitle("service-����");
//		dto.setBcontent("service-�۾���");
//		dto.setBip(InetAddress.getLocalHost().getHostAddress());
//		System.out.println( service.edit(dto) );
		
		//����
//		BoardDto dto = new BoardDto();
//		dto.setBname("second");
//		dto.setBpass("2222");
//		dto.setBtitle("service-����");
//		dto.setBcontent("service-�۾���");
//		System.out.println( service.insert(dto) );
		
		//��ü���
//		System.out.println( service.selectAll() );
	}
	
}
