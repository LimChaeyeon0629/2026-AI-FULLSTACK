package com.the703.controller;

import java.io.File;
import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class UploadController {
	//1. ���ε��� ��
	@RequestMapping(value ="/upload", method =RequestMethod.GET)
	public String upload_get() { return "basic/uploadForm"; }
	
	//2. ���ε� ���
	@RequestMapping(value ="/upload", method =RequestMethod.POST)
	public String upload_post(	@RequestParam("name") String name,
								@RequestParam("file") MultipartFile file,
								Model model) throws IllegalStateException, IOException { 
		//���ε� �ø��� ��� (ó��) - import java
		if( !file.isEmpty() ) {
			String 	uploadPath 	= "C:/file/";				// ���ϸ� ��������
			File 	dest		= new File( uploadPath + file.getOriginalFilename() );
			file.transferTo(dest); //�ø���
			
			System.out.println("���ε�����: " + name + "/" + "���ε强��> " + dest.getAbsolutePath());
			model.addAttribute("file", file.getOriginalFilename());
			model.addAttribute("name", name);
		}
		return "basic/uploadResult"; }
}