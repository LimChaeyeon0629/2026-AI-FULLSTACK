package com.the703.service;

import com.the703.dto.AuthDto;
import com.the703.dto.AuthUserDto;
import com.the703.dto.UserDto;

public interface UserService {

	public     AuthUserDto    readAuth( String email );
	
	public int      	 insert(UserDto dto);  //ȸ������ 
	
	public String   findByEmail( String email); //�̸����ߺ��˻�
	public UserDto  findByEmailUserInfo(   String email);
//	public UserDto  findByNickname(   String nickname);
	public String  findByNickname(   String nickname);
	
}

